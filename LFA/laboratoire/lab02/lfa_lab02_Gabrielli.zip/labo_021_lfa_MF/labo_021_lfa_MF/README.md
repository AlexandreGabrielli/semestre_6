# Lab 02

* Create a Python 3 virtualenv
* `pip install -r requirements.txt`
* `jupyter notebook`
* Follow instruction in the provided notebook
