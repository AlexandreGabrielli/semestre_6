# Laboratoire 7 - Optimisations de compilation

**Auteur : Alexandre Gabrielli** 

**Date : 04.05.2020**

**Introduction**

Dans ce laboratoire nous allons montrer trois exemples d'optimisation de code c, pour chacun des exemples nous montrerons une version non-optimiser , une version optimisée par le compilateur et une version que nous avons optimiser par nos soins

Exemple 1 - négation d'une valeur selon un flag

[Code](https://godbolt.org/z/HXBktf)

Il nous arrive souvent de devoir inverser un nombre selon une condition déjà calculer. Pour ce faire en c nous utilisons la plupart du temps un if statement ou une condition ternaire ce qui produit à un code compiler avec un cmp qui est couteux car il s'agit d'un branchement difficile à prévoir par le processeur. 

Lorsque nous utilisons l'optimisateur du compilateur on voit que le code est beaucoup réduit et qu'il va quand même effectuer une comparaison bit a bit (test ) et va effectuer la négation par rapport au flag résultat (cmovne).

Dans la version du site [ Stanford](https://graphics.stanford.edu/~seander/bithacks.html#ConditionalNegate) que nous optimisons ensuite par le compilateur on voit qu'il n'y a plus de branchement conditionnel , ce qui pourrait selon les cas permettre un gain de performance. 

**Exemple 2 - Fibonacci** 

[Code](https://godbolt.org/z/wWp8k2)

On voit avec cette exemple un code qui ne peut pas être optimiser par le compilateur, ici nous réalisons la suite de Fibonacci en utilisant une récursion ; cella est très gourmand car nécessite beaucoup d'appel de fonction et prend énormément de temps à calculer par exemple Fibonacci(100). On peut voir qu'il n'y a quasiment pas de différence entre le code optimisé par le compilateur et le code sans optimisation. Or lorsque l'on sait qu'on peut à l'instar de toutes suites géométrique ou arithmétique calculer directement la valeur sans passer par toutes les étapes intermédiaires on voit que même si le code est un peu plus long on peut calculer en quelques millième de seconde Fibonacci(100) alors qu’avec une fonction récursive cella prend plusieurs minutes. 

**Exemple 3 - Loop Unrolling**

Un des exemples les plus fréquents d'optimisation (vue en cours ou sur internet) et le Loop unrolling. Cette technique permet un grand gain du nombre d'instruction simplement en réduisant le nombre d'itération sur une boucle. 

Dans notre exemple situe [ici](https://godbolt.org/z/LtsEJW), nous effectuons une opération (ici une multiplication) sur chaque élément d'un array. De maniérer naïve nous itérons sur chaque élément de l'array et remplaçons sa valeur. On voit que l'optimisateur ne peut pas faire grand-chose de mieux et l'instruction de saut empêche toute optimisation. Cependant si nous choisissons de réduire le nombre de saut nous pouvons réaliser plusieurs opérations par boucle. Bien que le code semble plus long de première vue cella permet de gagner énormément de temps de compilation.

Une manière d'amélioré encore la rapidité et de générée du code vectoriel mais nous verrons cella plus tard dans le cours.

**Conclusion**

Durant ce laboratoire j'ai pu voir et comprendre que le compilateur n'est pas un outil miracle pour l'optimisation. Non seulement il est extrêmement conservateur et donc ne peu optimisé s'il ne peut pas prouver qu'il n'y pas de perte (ce qui arrive souvent lorsque les variables se cache derrière des pointeurs), mais aussi il ne peut pas facilement détecter des Loop unrolling ou tout ce qui est mathématique comme les suites et série. 

Maintenant je comprends mieux l'intérêt d'utiliser des qualificateurs comme volatile ou de sois même écrire du code vectoriel afin d'aider le compilateur à accomplir complétement son travail pour utiliser au meilleur de ces capacités mon matérielle. 

 