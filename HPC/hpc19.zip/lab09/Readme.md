# High Perfomance Computing (HPC) - Parallélisme

Auteur : David Jaquet

## Introduction

Dans ce laboratoire, nous devions rédiger et optimiser le programme `stats_count` en exploitant le parallélisme à l'aide de la librairie `pthread`.

Pour ce faire, un chablon nous a été fourni. Ce dernier contient la fonction `size_t stats_count(struct char_stats *stats)` doit parcourir le fichier `text.txt` ouvert par `stats_init()` et compter le nombre d’occurrences de chaque lettre de l’alphabet. L'alphabet et constitué des caractères `[a-z][A-Z][0-9]` et les caractères spéciaux seront ignorés. la fonction `stats_count` retourne le nombre de caractères traités.

Il est important de noter que le fichier texte ouvert peut être énorme (ordre du GB). En conséquence, la fonction `fopen` sera utilisée.

## Modification sur la structure fournie

Le programme fournit comportait uniquement trois fonctions servant à l'initialisation, le comptage des lettres alphanumériques dans un texte ainsi que la libération des statisques. Nous avions également à disposition une structure `char_stats` contenant uniquement un attribut `count` représentant le nombre de lettres comptées.

J'ai donc commencé par modifié la structure fournie de la manière suivante :

```c
struct char_stats {
	const char *path;

	size_t fileSize;
 	size_t count;

 	char chars[62];
};
```

On peut voir dans le code ci-dessus que j'ai rajouté plusieurs éléments. La pluparts des attributs ayant un nom suffisemment parlant, je ne vais détaillé que le tableau `chars`. Ce dernier est un le tableau contenant le nombre des différentes lettres. Dans mon implémentation, j'ai choisi de manière arbitraire la représentation suivante :

| Index     | 0    | ...  | 25   | 26   | ...  | 51   | 52   | ...  | 61   |
| --------- | ---- | ---- | ---- | ---- | ---- | ---- | ---- | ---- | ---- |
| Caractère | a    | ...  | z    | A    | ...  | Z    | 0    | ...  | 9    |

Si nous exécutons l'instructions `chars[0]`, nous obtiendrons le nombre de fois où le caractère _a_ est présent dans le texte.

## Compter les lettres alphanumériques

C'est dans cette partie où intervient le parrallélisme dans mon programme ! Un tableau de `pthread_t` est créé contenant chacun de nos `threads`. Je crée également un tableau d'une structure contenant les différents paramètres  nécessaires au `thread` pour fonctionner. Cette structure contient les éléments suivants :

- **path** : Nom du fichier
- **chars** : Tableau contenant le nombre d'occurence de chaque caractères ASCII
- **startIndex** : Index du premier caractère à compter
- **nbCharsToCount** : Nombre de caractères maximum à compter

Une fois mes tableaux créés, je commence par définir les différentes valeurs aux paramètres des threads pour l'exécuter grâce à la fonction `thread_create`.

```c
// Initialize params and start the threads
for(size_t i = 0; i < NB_THREADS; i++) {
    params[i] = malloc(sizeof(struct thread_params));
    params[i]->path = stats->path;
    params[i]->chars = calloc(256, sizeof(size_t));
    params[i]->startIndex = startIndex;
    params[i]->nbCharsToCount = nbCharsToCount;

    pthread_create(&(threads[i]), NULL, (void *)count_chars, params[i]);
    startIndex += nbCharsToCount;
}
```

Ensuite, nous pouvons donc commencer a parler de la phase de dénombrage. Nous ouvrons donc le fichier et nous définissons un pointeur à l'index de départ voulu. Ensuite, chaque caractère est parcouru est la case correspondante dans notre tableau `chars` est incrémenté. Il est important de noter que chaque caractère est compté à cet endroit. Ce choix a été fait car il aurait été lourd en terme de nombre d'instruction et de temps d'exécution de vérifier si chaque caractère est un caractère alphanumérique.

```c
void *count_chars(void *args) {
	struct thread_params *params = (struct thread_params *) args;

	FILE *file = fopen(params->path, "r");
	fseek(file, params->startIndex, SEEK_SET);

	int c;

	for(size_t i = 0; i < params->nbCharsToCount; i++) {
		c = fgetc(file);

		if(c == EOF)
			break;

		params->chars[c]++;
	}

	fclose(file);

	return NULL;
}
```

En dernierère étape, nous pouvons ensuite compter le nombre de caractères présent dans les tableaux de nos différents `threads`. Une utilisation de la table `ASCII` a été faite pour savoir quel caractère correspond à quelle valeur.

```c
// Count the chars
for(size_t i = 0; i < NB_THREADS; i++) {
    // From 'a' to 'z' and 'A' to 'Z'
    for(size_t j = 0; j < 26; j++) {
        stats->count += params[i]->chars[j+65];		// Uppercase, char 65 is 'A'
        stats->count += params[i]->chars[j+97];		// Lowercase, char 97 is 'a'

        stats->chars[j] = params[i]->chars[j+65];	// Uppercase
        stats->chars[j+26] = params[i]->chars[j+97];// Lowercase
    }

    // From '0' to '9'
    for(size_t j = 0; j < 10; j++) {
        stats->count += params[i]->chars[j+48];		// char 97 is '0'

        stats->chars[j+52] = params[i]->chars[j+48];
    }
}
```

## Libération

Tous les éléments ont été libéré de manière normale grâce à la fonction `free`. Il est toutefois important de noter que le tableau de `threads` ainsi que les tableaux de caractères ont été libéré à la fin de la fonction `stats_count` et non dans la fonction `stats_clear`. Comme ces éléments ne sont pas liés à la structures, des problèmes de types **memory_leaks** si ils n'étaient pas libérés dans la fonction dans laquelle ils ont été créés.

## Mesures

Mes mesures ont été effectuées avec un nombre de threads différents. Pour simuler une version sans parrallélisme, une version avec un seul `thread` a été exécutée. Ces temps ne sont pas les mêmes qu'une version réelles sans parrallélisme car nous effectuons des instructions inutiles en plus qu'on ne ferait évidemment pas si le programme avait été prévu pour fonctionnement avec un seul `thread` (création du `thread`, compter le nombre de caractères que le thread doit compter, ...).

Voici un graphique représentant avec les chiffres récupérés :

![Temps mesuré](graphique.png)

On peut voir l'amélioratiion extrémement simplement l'amélioration apportée par le parrallélisme dans ce graphique. Il est intéressant de voir que plus on rajouter de `thread`, plus le temps d'exécution baisse, mais uniquement jusqu'à ce qu'on atteigne quatre `threads`. Cela s'explique car les mesures ont été prises sur l'ordinateur **A07PC12** de l'école d'ingénieur d'yverdon et que le processeur de cet ordinateur ne possède que 4 coeurs.

J'ai comparé mes temps avec un collègue afin de me rendre compte de l'efficacité de mon code. Ce dernier a plus ou moins la même méthodologie que moi. La principale différence était qu'il ne compte pas chaque caractère, mais uniquement les alphanumériques. Mon collègue doit donc vérifier la valeur ASCII de chaque caractères. Son temps est supérieur au mien et la différence s'explique principalement à cause de ces vérifications.

## Améliorations possibles

### Utilisation de fread

Une amélioration possible aurait été l'utilisation de la fonction `fread` à la place de la fonction `fgetc` lors du dénombrage des caractères. `fgetc` nous fait un perdre un temps considérable car nous ne traitons qu'un caractère à la fois. Nous faisons donc un grand nombre d'appel à une fonction qui est très couteuse.

En comparaison, la fonction `fread` récupère plusieurs caractères à la fois et cela à pour conséquence logique de réduire le nombre d'appel à la fonction.

Cette amélioration n'a malheureusement pas pu être implémenté dû à un manque de temps investit à cause d'une charge de cours importante en fin de semestre et à mes examens approchant.

## Conclusion

J'ai aimé ce laboratoire qui était d'une difficulté bien plus accessible pour moi que plusieurs ancien laboratoire que nous avons eu dans ce cours. Il m'a également permi de revoir le parallélisme qui est une notion que je n'avais absolument plus retravaillé depuis les cours de SYE et de PCO. Ce laboratoire montre que le parallélisme peut grandement augmenter les performances, mais qu'il ne faut pas pour autant laisser de côté les performances du code. Mon graphique est la comparaison avec mon collègue le prouve.