#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include "stats_count.h"

#define NB_THREADS 4

struct char_stats *stats_init(const char *path) {
	struct char_stats *stats = (struct char_stats*) malloc(sizeof(struct char_stats));
	FILE *file = fopen(path, "r");

	// To get the size of the file
	// Found in https://stackoverflow.com/questions/238603/how-can-i-get-a-files-size-in-c
	fseek(file, 0L, SEEK_END);
	stats->fileSize = ftell(file);
	fclose(file);

	stats->path = path;

	return stats;
}

void *count_chars(void *args) {
	struct thread_params *params = (struct thread_params *) args;

	FILE *file = fopen(params->path, "r");
	fseek(file, params->startIndex, SEEK_SET);

	int c;

	for(size_t i = 0; i < params->nbCharsToCount; i++) {
		c = fgetc(file);

		if(c == EOF)
			break;

		params->chars[c]++;
	}

	fclose(file);

	return NULL;
}

size_t stats_count(struct char_stats *stats) {
	pthread_t threads[NB_THREADS];
	struct thread_params *params[NB_THREADS];

	size_t startIndex = 0,
		   nbCharsToCount = stats->fileSize / NB_THREADS;

	stats->count = 0;

	// Initialize params and start the threads
	for(size_t i = 0; i < NB_THREADS; i++) {
		params[i] = malloc(sizeof(struct thread_params));
		params[i]->path = stats->path;
		params[i]->chars = calloc(256, sizeof(size_t));
		params[i]->startIndex = startIndex;
		params[i]->nbCharsToCount = nbCharsToCount;

		pthread_create(&(threads[i]), NULL, (void *)count_chars, params[i]);
		startIndex += nbCharsToCount;
	}

	// Wait until the end of the threads
	for(size_t i = 0; i < NB_THREADS; i++) {
		if(pthread_join(threads[i], NULL) != 0){
			perror("pthread_join() error !");
			exit(1);
		}
	}

	// Count the chars
	for(size_t i = 0; i < NB_THREADS; i++) {
		// From 'a' to 'z' and 'A' to 'Z'
		for(size_t j = 0; j < 26; j++) {
			stats->count += params[i]->chars[j+65];		// Uppercase, char 65 is 'A'
			stats->count += params[i]->chars[j+97];		// Lowercase, char 97 is 'a'

			stats->chars[j] = params[i]->chars[j+65];	// Uppercase
			stats->chars[j+26] = params[i]->chars[j+97];// Lowercase
		}

		// From '0' to '9'
		for(size_t j = 0; j < 10; j++) {
			stats->count += params[i]->chars[j+48];		// char 97 is '0'

			stats->chars[j+52] = params[i]->chars[j+48];
		}
	}

	for(size_t i = 0; i < NB_THREADS; i++) {
		free(params[i]->chars);
		free(params[i]);
	}

	FILE *result = fopen("result.txt", "w");
	fprintf(result, "count: %zu\n", stats->count);
	fclose(result);

	return stats->count;
}

void stats_clear(struct char_stats *stats) {
	free(stats);
}