#pragma once

#define KB (1 << 10)
#define MB (1 << 20)

#define RUNS 5
#define ITERATIONS 10

#define FILENAME "text.txt"
