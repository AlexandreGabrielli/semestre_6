#pragma once

struct char_stats {
	const char *path;

	size_t fileSize;
 	size_t count;

 	char chars[62];
};

struct thread_params {
	const char *path;

	size_t *chars;

	size_t startIndex;
	size_t nbCharsToCount;
};

/* Opens a (potentially huge) text file to be processed,
 * initializes threads and returns a pointer to a struct char_stats handle. */
struct char_stats *stats_init(const char *path);

/* Parse the file opened by stats_init() and gathers per-character statistics.
 * The alphabet processed is [a-z][A-Z][0-9]. Other symbols are ignored.
 * Returns the number of characters from the alphabet processed.
 */
size_t stats_count(struct char_stats *stats);

/* Clears everything initialized by char_init() */
void stats_clear(struct char_stats *stats);
