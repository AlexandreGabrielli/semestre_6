#!/bin/bash
git submodule init
git submodule update

# google benchmark
cd lib/benchmark
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release -DBENCHMARK_DOWNLOAD_DEPENDENCIES=ON ../
make -j4
cd ../../..
