//
//  util.h
//  Labo1HPC
//
//  Created by Max Caduff on 26.02.19.
//  Copyright (c) 2019 Max Caduff. All rights reserved.
//

#ifndef __Labo1HPC__util__
#define __Labo1HPC__util__

#include <stdio.h>


void xorSwap (uint64_t* first, uint64_t* second);

#endif /* defined(__Labo1HPC__util__) */
