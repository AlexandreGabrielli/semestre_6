//
//  util.c
//  Labo1HPC
//
//  Created by Max Caduff on 26.02.19.
//  Copyright (c) 2019 Max Caduff. All rights reserved.
//

#include "util.h"

void xorSwap (uint64_t* first, uint64_t* second) {
    
    if (first != second) {
        *first ^= *second;
        *second ^= *first;
        *first ^= *second;
    }
}

