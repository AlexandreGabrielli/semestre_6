//
//  array_util.c
//  Labo1HPC
//
//  Created by Max Caduff on 24.02.19.
//  Copyright (c) 2019 Max Caduff. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "array_util.h"
#include "util.h"


uint64_t *array_init(const size_t len) {
    
    uint64_t* tab = malloc(sizeof(uint64_t)*len);
    for (int i = 0; i<len; i++) {
        tab[i] = rand() % 10000;
    }
    return tab;
}


void array_clear(uint64_t *data) {
    
    free(data);
}


void arrayPrint (uint64_t* list, size_t len) {
    printf("[ ");
    for (size_t i = 0; i<len; i++) {
        printf("%5llu ", list[i]);
    }
    printf(" ]\n");
}


// last is included in sorting
void quickSortArray (uint64_t* first, uint64_t* last) {
    
    if (first < last) {
        
        uint64_t* pivot = first, *small = first, *high = first + 1;
        
        while (high <= last) {
            
            if (*high <= *pivot) {
                
                small ++;
                xorSwap(small, high);
            }
            high ++;
        }
        xorSwap(small, pivot);
        
        quickSortArray(pivot, small - 1);
        quickSortArray(small + 1, high -1);
    }
}


void array_sort(uint64_t *data, const size_t len) {
    
    quickSortArray(data, data + len);
    
}

