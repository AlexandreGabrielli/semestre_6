//
//  list_util.c
//  Labo1HPC
//
//  Created by Max Caduff on 24.02.19.
//  Copyright (c) 2019 Max Caduff. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "list_util.h"
#include "util.h"

struct list_element {
    uint64_t data;
    struct list_element* next;
};


struct list_element *list_init(size_t len) {
    
    struct list_element* head = NULL;
    struct list_element* last = NULL;
    
    // could allocate directly sizeof(elt)*len since nothing is implemented to edit the list
    for (int i = 0; i<len; i++) {
        struct list_element* tmp = malloc(sizeof(struct list_element));
        tmp->data = rand() % 10000;
        tmp->next = NULL;
        
        // 1st element created
        if ( !head ) {
            head = last = tmp;
        }
        // other elements
        else {
            last->next = tmp;
            last = last->next;
        }
    }
    return head;
}

void list_clear(struct list_element *head) {
    
    struct list_element* current = head;
    
    while (current) {
        struct list_element* tmp = current;
        current = current->next;
        free(tmp);
    }
}

// last is excluded from sorting
void quickSortList (struct list_element* first, struct list_element* last) {
    
    if (first != last && first->next != last ) {
        
        struct list_element* pivot = first, *small = first, *high = first->next;
        
        while (high != last) {
            
            if (high->data <= pivot->data ) {
                small = small->next;
                xorSwap(&small->data, &high->data);
            }
            high = high->next;
        }
        // swap small & pivot
        xorSwap(&small->data, &pivot->data);

        quickSortList(pivot, small);
        quickSortList(small->next, high);
    }
}

void list_sort(struct list_element *head) {
    
    quickSortList(head, NULL);
}


void listPrint (struct list_element* list) {
    struct list_element* cur = list;
    printf("[ ");
    while ( cur ) {
        printf("%5llu ", cur->data);
        cur = cur->next;
    }
    printf(" ]\n");

}








