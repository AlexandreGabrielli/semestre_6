#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#define COMPONENT_GRAYSCALE 1
#define COMPONENT_RGB 3

/* RGB weights for grayscale conversion */
#define LUMINOSITY_R 0.21
#define LUMINOSITY_G 0.72
#define LUMINOSITY_B 0.07

/* PNG format allows for padding between rows of data */
#define PNG_STRIDE_IN_BYTES 0

struct grayscale_img {
    /* we use int types here instead of size_t because we receive
     * erroneous data from stbi_load otherwise, even with proper casts
     * in the stbi_load() call */
    int width;
    int height;
    int n; /* number of components per pixel */

    uint8_t *data;
    uint8_t *processed_data;
};

static void component_assert(const int actual, const int expected)
{
    if (actual != expected) {
        fprintf(stderr, "[%s] image has %d components, expected %d. Aborting\n", __func__, actual, expected);
        exit(EXIT_FAILURE);
    }
}

struct grayscale_img *grayscale_init(const char *img_path)
{
    FILE *fimg;
    struct grayscale_img *gs_img;

    /* open image file */
    fimg = fopen(img_path, "rb");
    if (!fimg) {
        fprintf(stderr, "[%s] fopen error (%s)\n", __func__, img_path);
        perror(__func__);
        exit(EXIT_FAILURE);
    }

    /* struct allocation */
    gs_img = malloc(sizeof(struct grayscale_img));    
    if (!gs_img) {
        fprintf(stderr, "[%s] struct malloc error\n", __func__);
        perror(__func__);
        exit(EXIT_FAILURE);
    }

    /* load image using stb lib */
    gs_img->data = stbi_load(img_path, &gs_img->width, &gs_img->height, &gs_img->n, 0);    
    if (!gs_img->data) {
        fprintf(stderr, "[%s] stbi_load() returned NULL\n", __func__);
        exit(EXIT_FAILURE);
    }

    /* grayscale array allocation for rgb->grayscale conversion */
    gs_img->processed_data= malloc(gs_img->width * gs_img->height);
    if (!gs_img->processed_data) {
        fprintf(stderr, "[%s] grayscale malloc error\n", __func__);
        perror(__func__);
        exit(EXIT_FAILURE);
    }

    fprintf(stderr, "[%s] image %s loaded (%d components, %dx%d)\n", __func__, img_path, gs_img->n, gs_img->width, gs_img->height);
    return gs_img;
}

void grayscale_convert(struct grayscale_img *gs_img)
{
    size_t r_index = 0, g_index = 1, b_index = 2;

    component_assert(gs_img->n, COMPONENT_RGB);

    /* rgb to grayscale conversion */
    for (int i = 0; i < gs_img->height; i++) {
        for (int j = 0; j < gs_img->width; j++) {
            gs_img->processed_data[gs_img->width*i + j] = 
                LUMINOSITY_R * gs_img->data[r_index] +
                LUMINOSITY_G * gs_img->data[g_index] +
                LUMINOSITY_B * gs_img->data[b_index];

            r_index += COMPONENT_RGB;
            g_index += COMPONENT_RGB;
            b_index += COMPONENT_RGB;
        }
    }
}

void grayscale_dither_none(struct grayscale_img *gs_img)
{
    uint8_t pixel;

    for (int i = 0; i < gs_img->height; i++) {
        for (int j = 0; j < gs_img->width; j++) {
            pixel = gs_img->data[gs_img->width*i + j];

            if (pixel < (255 >> 1))
                gs_img->processed_data[gs_img->width*i + j] = 0;
            else
                gs_img->processed_data[gs_img->width*i + j] = 255;
        }
    }
}

void grayscale_dither_simple(struct grayscale_img *gs_img)
{
    int16_t pixel; /* signed int16_t because pixel can overflow when error is added */

    component_assert(gs_img->n, COMPONENT_GRAYSCALE);

    for (int i = 0; i < gs_img->height; i++) {
        int8_t error = 0;

        for (int j = 0; j < gs_img->width; j++) {
            pixel = gs_img->data[gs_img->width*i + j] + error;

            if (pixel < (255 >> 1)) {
                /* pixel is black */
                gs_img->processed_data[gs_img->width*i + j] = 0;
                error = pixel < 0 ? 0 : pixel;
            }
            else {
                /* pixel is white */
                gs_img->processed_data[gs_img->width*i + j] = 255;
                error = pixel > 255 ? 0 : pixel - 255;
            }
        }
    }
}

/* 8x8 Bayer ordered dithering. Inspired by Lee Daniel Crocker's http://www.efg2.com/Lab/Library/ImageProcessing/DHALF.TXT */
void grayscale_dither_ordered(struct grayscale_img *gs_img)
{
    uint8_t pixel;
    const uint8_t pattern[8][8] = {
        { 0, 32,  8, 40,  2, 34, 10, 42},   /* 8x8 Bayer ordered dithering  */
        {48, 16, 56, 24, 50, 18, 58, 26},   /* pattern.  Each input pixel   */
        {12, 44,  4, 36, 14, 46,  6, 38},   /* is scaled to the 0..63 range */
        {60, 28, 52, 20, 62, 30, 54, 22},   /* before looking in this table */
        { 3, 35, 11, 43,  1, 33,  9, 41},   /* to determine the action.     */
        {51, 19, 59, 27, 49, 17, 57, 25},
        {15, 47,  7, 39, 13, 45,  5, 37},
        {63, 31, 55, 23, 61, 29, 53, 21} };

    component_assert(gs_img->n, COMPONENT_GRAYSCALE);

    for (int i = 0; i < gs_img->height; i++) {
        for (int j = 0; j < gs_img->width; j++) {
            pixel = gs_img->data[gs_img->width*i + j] >> 2; /* scaled to 0..63 for Bayer matrix comparison */

            if (pixel > pattern[j & 7][i & 7])
                gs_img->processed_data[gs_img->width*i + j] = 255;
            else
                gs_img->processed_data[gs_img->width*i + j] = 0;
        }
    }
}

void grayscale_export(const char *img_path, const struct grayscale_img *gs_img)
{
    if (!stbi_write_png(img_path, gs_img->width, gs_img->height, COMPONENT_GRAYSCALE, gs_img->processed_data, PNG_STRIDE_IN_BYTES)) {
        fprintf(stderr, "[%s] export failed\n", __func__);
        exit(EXIT_FAILURE);
    }

    fprintf(stderr, "[%s] PNG file %s exported (%dx%d)\n", __func__, img_path, gs_img->width, gs_img->height);
}

void grayscale_clear(struct grayscale_img *gs_img)
{
    stbi_image_free(gs_img->data);
    free(gs_img->processed_data);
    free(gs_img);
}
