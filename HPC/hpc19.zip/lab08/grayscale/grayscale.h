#pragma once

struct grayscale_img;

/* opens an image whose format is supported by the stb library.
 * initializes and returns a struct grayscale_img with allocated data buffers,
 * image dimensions & number of components */
struct grayscale_img *grayscale_init(const char *img_path);

/* takes an RGB image as input contained in gs_img->data
 * and outputs a grayscale image in gs_img->processed_data */
void grayscale_convert(struct grayscale_img *gs_img);

/* performs a naive conversion on a grayscale image contained in gs_img->data
 * to a black & white image stored in gs_img->processed_data */
void grayscale_dither_none(struct grayscale_img *gs_img);

/* applies a simple dithering algorithm with error propagation on gs_img->data
 * and stores the result in gs_img->processed_data */
void grayscale_dither_simple(struct grayscale_img *gs_img);

/* applies an ordered dithering algorithm using a 8x8 Bayer matrix on gs_img->data
 * and stores the result in gs_img->processed_data */
void grayscale_dither_ordered(struct grayscale_img *gs_img);

/* exports a grayscale PNG image contained in gs_img->processed_data
 * to file "img_path" */
void grayscale_export(const char *img_path, const struct grayscale_img *gs_img);

/* frees all allocated structures & buffers from grayscale_init() */
void grayscale_clear(struct grayscale_img *gs_img);
