#pragma once

#define KB (1 << 10)
#define MB (1 << 20)

#define RUNS 5
#define ITERATIONS 10


#ifdef BENCHMARK_CONVERT

#define INPUT_IMG_PATH "img_rgb"
#define OUTPUT_IMG_PATH "img_grayscale.png"

#else

#define INPUT_IMG_PATH "img_grayscale.png"
#define OUTPUT_IMG_PATH "img_blackwhite.png"

#endif /* BENCHMARK_CONVERT */
