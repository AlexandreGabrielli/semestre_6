/* 26.01.16 - Xavier Ruppen - HPC - REDS - HEIG-VD */

#include <stdio.h>
#include <stdlib.h>
#include "benchmark/benchmark.h"
#include "bench.h"

extern "C" {
#include "grayscale.h"
}

class DitheringFixture : public benchmark::Fixture {
public :
    void SetUp(const ::benchmark::State&)
    {
        gs_img = grayscale_init(INPUT_IMG_PATH);
    }

    void TearDown(const ::benchmark::State&)
    {
        grayscale_export(OUTPUT_IMG_PATH, gs_img);
        grayscale_clear(gs_img);
    }

protected :
    struct grayscale_img *gs_img;
};


BENCHMARK_F(DitheringFixture, grayscale_convert)(benchmark::State& state) {
    while (state.KeepRunning()) {
#ifdef BENCHMARK_CONVERT
      grayscale_convert(gs_img);
#elif BENCHMARK_DITHER_NONE
      grayscale_dither_none(gs_img);
#elif BENCHMARK_DITHER_SIMPLE
      grayscale_dither_simple(gs_img);
#elif BENCHMARK_DITHER_ORDERED
      grayscale_dither_ordered(gs_img);
#endif
    }
}

BENCHMARK_MAIN();
