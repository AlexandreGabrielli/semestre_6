#pragma once

#include <stddef.h>
#include <stdbool.h>

struct matrix;

/* returns a pointer to an allocated, non-initialized matrix of dimensions row x col */
struct matrix *matrix_init(const size_t row, const size_t col);

/* returns a pointer to an allocated, initialized and invertible square matrix
 * dim: square matrix dimensions */
struct matrix *matrix_init_invertible(const size_t dim);

/* free a previously allocated matrix */
void matrix_clear(struct matrix *m);

/* print a matrix. Print messages are prefixed with "name" */
void matrix_print(const struct matrix *m, FILE *output);
void matrix_save(struct matrix *m, const char *path);

/* invert an invertible matrix.
 * m_src: invertible matrix to invert
 * m_dst: inverted matrix, must be allocated with matrix_init first
 * returns false if dimension mismatch between m_src and m_dst */
bool matrix_inv(const struct matrix *m_src, struct matrix *m_dst);
