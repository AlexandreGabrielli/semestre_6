#!/usr/bin/octave --no-history
# to be called for each student individually

# double comparison tolerance
DELTA = 0.0001;

mat_init_prefix = "_init";
mat_inverse_prefix = "_inverse";
mat_extension = ".mat";

arg_list = argv();

if nargin != 2
    printf("Usage: %s <student_name> <dimension>\n", program_name());
    exit
endif

# arg parsing
student_name = arg_list{1};
dim = arg_list{2};

# file names
mat_init_name = strcat(student_name, mat_init_prefix, mat_extension);
mat_inverse_name = strcat(student_name, mat_inverse_prefix, mat_extension);

# load matrices from files
mat_init = load(mat_init_name);
mat_inverse = load(mat_inverse_name);

# invert init matrix
mat_inverse_octave = inv(mat_init);

# compare octave's inversion with student's inversion
printf("[%s] %s %s\n", student_name, mat_init_name, mat_inverse_name);

if (mat_inverse <= mat_inverse_octave + DELTA) && (mat_inverse >= mat_inverse_octave - DELTA)
    printf("PASS\n");
else
    printf("FAIL\n");
endif
