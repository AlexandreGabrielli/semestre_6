/* 26.01.16 - Xavier Ruppen - HPC - REDS - HEIG-VD */

#include <stdio.h>
#include <stdlib.h>
#include "benchmark/benchmark.h"
#include "bench.h"

extern "C" {
#include "matrix.h"
}

class MatrixFixture : public benchmark::Fixture {
public :
    void SetUp(const ::benchmark::State&)
    {
        m = matrix_init_invertible(MATRIX_DIM);
        m_inverted = matrix_init(MATRIX_DIM, MATRIX_DIM);
    }

    void TearDown(const ::benchmark::State&)
    {
        matrix_save(m, "m_init.mat");
        matrix_save(m_inverted, "m_inverse.mat");
        matrix_clear(m);
        matrix_clear(m_inverted);
    }

protected :
    struct matrix *m, *m_inverted;
};

BENCHMARK_F(MatrixFixture, matrix_inv)(benchmark::State& state) {
    while (state.KeepRunning()) {
        if (!matrix_inv(m, m_inverted)) {
            fprintf(stderr, "[%s] wrong matrix sizes\n", __func__);
            exit(EXIT_FAILURE);
        }
    }
}

BENCHMARK_MAIN();
