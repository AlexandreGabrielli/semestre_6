#pragma once

#define KB (1 << 10)
#define MB (1 << 20)

/* Customizable */
#define RANDOM_DOUBLE_MAX 10.0

#ifndef MATRIX_DIM
#define MATRIX_DIM 1000
#endif

#define RUNS 5
#define ITERATIONS 10
