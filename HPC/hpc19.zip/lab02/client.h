#pragma once

void client_start(const char *ipv4_srv, unsigned short port_srv);
