#pragma once

#define KB (1 << 10)
#define MB (1 << 20)

/* Customizable */
#define RANDOM_DOUBLE_MAX 10.0

#define N 1

#define SIZE 1000

#define RUNS 5
#define ITERATIONS 10

