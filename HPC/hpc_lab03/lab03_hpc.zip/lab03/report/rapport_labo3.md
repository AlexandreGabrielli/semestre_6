## question 

## Pourquoi l’une de ces deux fonctions est plus performante que l’autre ?

La différence entre les deux code est l'ordre d'accès de donnée de la matrice. 

pour le premier nous avons 

```c++
    for (size_t i = 0; i < m1->row; i++)
        for (size_t j = 0; j < m2->col; j++)
            for (size_t k = 0; k < m1->col; k++)
                m3->data[i][j] += m1->data[i][k] * m2->data[k][j];
```

soit nous accédons a m1-> row puis m2->col et après à m1->col 

Pour le deuxième 

```c++
for (size_t i = 0; i < m1->row; i++)
        for (size_t k = 0; k < m1->col; k++)
            for (size_t j = 0; j < m2->col; j++)
                m3->data[i][j] += m1->data[i][k] * m2->data[k][j];
```

nous accédons d'abords à m1->row puis a m1->col et ensuite a m2->col.

Ce qui me fait dire que comme dans le code optimiser nous accédons successivement au deux donnée de m1 tendis que dans le second nous chargeons entre les deux m2 il y aurai plus de cache miss.

Nous pourrions vérifier cela avec d'autre outils tel que gprof mais nous préférons nous concentrée sur les fonctions de tri suivante.

## fonction de tri

j'ai essayer exécuter gbench.cpp (code remplacer dans code/), malheureusement j'ai des segmentations fault que je n'avais pas avant. De ce fait et ayant d'autre chose a rattraper.



