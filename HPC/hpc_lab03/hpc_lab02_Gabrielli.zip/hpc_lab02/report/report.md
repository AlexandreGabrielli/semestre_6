# HPC laboratoire 2

### réponse au question du laboratoire

afin de facilité la correction nous mettons ici les réponse au question posé, bien qu'elle sont due a nos expérimentations détailler plus tard.

- Entre la première exécution du programme et les suivantes sur le même fichier, que remarquez-vous et comment l’expliquez-vous ? 

Si nous effectuant deux fois le programme de suite sur le même fichier nous remarquons que la deuxième exécution est beaucoup plus rapide, cela s'explique très certainement par ce que le fichier a été amené depuis le disque sur l'une des rams lors de la première exécution et donc lors de la seconde il n'y aura pas besoin d'aller chercher jusqu'aux disques. Nous pouvons affirmer cela car nous avons regarder le nombre relatif de cache-misses lors des deux exécutions est remarquons une baisse significatif lors de la deuxième exécution. 

-  Est-ce que la taille du fichier a une importance ?

Bien que nous n'ayons pas vraiment investigué dans ce sens là on peu quand même avancer que oui la taille du fichier a une importance, le programme n'ayant pas forcement accès a toute la ram nous allons forcement arriver a dépasser les capacité physique de la ram. et donc avoir quasiment autant de cache-misses lors de la 1er et deuxième exécution, A ce moment là la vitesse sera quand même plus rapide que lors de la 1er exécution car la cache de la MMU (TLB) aura encore en mémoire l'adresse physique correspondant à l'adresse virtuelle ce qui évitera de ramener cette information depuis le disque avant de pouvoir aller chercher la donné , par contre en imaginant une taille vraiment importante de fichier la TLB pourra elle aussi être complètement dépasser et a ce moment la 1er et deuxième exécution devrait être très proche l'une de l'autre.

## méthodologie

Nous avons commencer par réaliser un script qui permet de "benchmark" notre projet, ainsi pour récolter de nouvelle donner nous n'avons plus qu'a lancer le script. Nous utilisons les tags git pour pouvoir facilement récupérer les différentes version de notre amélioration et pouvoir ainsi navigué entre les différentes versions. nous choisissons d'effectuer pour chaque taille plusieurs mesures et d'en faire la médiane afin de réduire au maximum l'influence d'une valeur atypique.

benchmark: 

```sh
#!/bin/bash
# client_recv
arraySize=(1024 2048 4096 8192 16384 32768 65536 131072 262144 524288 1048576 2097152 4194304 8388608 16777216 33554432 67108864 13417728 268435456 536870912 1073741824 2147483648)
arrayBUFFER=(16777216 33554432 67108864)

for j in "${arrayBUFFER[@]}"
do
	for i in "${arraySize[@]}"
	do
		echo "FILE_SIZE = ${i} & BUFFER_SIZE = ${j}"
		make clean
		make all FILE_SIZE=${i} BUFFER_SIZE=${j} | grep 'time_report' >> result_BUFFERIZED_${j}.txt
	done
done
```

ce benchmark nous permet de définir des tailles de fichier et des tailles de buffer afin de réaliser les tests à la suite et rapidement. 

Nous avons donc du modifier le code et le makefile en conséquence pour réussir à passer la taille du buffer depuis une commande. le make all permet de voir si le fichier a été lu correctement du coder client (en regardant bien sur ce qui est écrit sur le prompt).

## info sur notre système
Comme nous allons certainement buffériser notre application nous désirons connaître la taille d'une page afin de buffériser avec des valeurs cohérente,nous utilisons la commande ``getconf PAGE_SIZE`` dans un shell pour connaitre la taille de notre page. D'autre information pouvant être intéressante pour discuter nos résultats est le nombre total de page physique que l'on obtiens grâce à la commande `getconf _PHYS_PAGES`  et aussi le nombre de page virtuelle que l'on obtient via la commande `getconf _AVPHYS_PAGES`.

info sur notre système:

|          |  SIZE    |
|:--------:|:--------:|
|PAGE_SIZE|4096 BYTES|
|PHYS_PAGES|4093084 pages|
|AVPHYS_PAGES|3597001 pages|

Nous avons aussi calculer les performances maximal en copiant simplement le fichier avec la commande dd, cette mesures est celle que nous ne devrions pas atteindre car cette commande système reproduit la zone de disque et nous nous devons passer par la carte réseaux ainsi incrémenter tout les bytes de 1. 

Nous avons fait cette commande avec plusieurs taille de fichier

| Taille  du fichier |  vitesse en MBytes/sec  |
|:--------:|:--------:|
|1 KB|          7.1          |
|2 kB|         14.7          |
|4.1 kB|         22.8          |
|8.2 kB|49.8|
|16 kB|62.2|
|33 kB|121|
|66 kB|108|
|131 kB|168|
|268 kB|115|
|524 kB|137|
|1 MB|118|
|2.1 MB|106|
|4.2 MB|167|
|8.4 MB|170|
|17MB|171|
|34MB|142|
|67 MB|166|
|13 MB|182|
|268 MB|181|
|537 MB|175|
|1.1 GB|150|
|2.1 GB|174|

on peut voir que pour les petits fichier il est difficile de qualifier la vitesse, a partir de quelque MB on voit que la vitesse tourne autour des 170 MBytes/sec. 

### version donner

Cette version est celle de base qui nous a été fourni, nous effectuons les mesures dessus. Nous n'arrivons pas à effectuer toutes les mesures car le programme prend beaucoup trop de temps.

#### Résultat
nous n'avons tester que avec un fichier de 1024 bytes est une moyenne de 830 bytes/sec.

## bufférisassions
Nous avons choisi d'amélioré notre code en ajoutant simplement de réaliser un buffer. La question qui nous reste a poser est la taille du buffer nous allons donc effectuer plusieurs mesures avec des tailles de buffer différentes allant de la taille d'une page a 2*le nombre de page virtuelle que nous avons. Et avec des tailles de fichier différents. Comme nous avons choisi de mettre notre buffer en uint8_t nous avons 8 bits par ligne dans le tableaux et comme nous avons la taille d'une page a 4096 BYTES nous savons que si nous mettons une taille de 4096 a notre buffer il y aura besoin 4096*8 bits = 4096 BYTES soit une pages.

#### Résultat

Sur la première ligne la taille du fichier et sur la première colonne la taille du buffer, le résultat est donné en MBytes/sec

##### data 

|  | Fichier/Buffer || 1 KB     | 2 kB     | 4.1 kB   | 8.2kB    | 16kB     | 33kB     | 66kB     | 131kB    | 26kB     | 524 kB   | 1 MB     | 2.1 MB   | 4.2 MB   | 8.4 MB   | 17MB      | 34MB     | 67  MB   | 13 MB    | 268MB    | 537 MB   | 1.1 GB | 2.1GB |
| :------ | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | --------- | -------- | -------- | -------- | -------- | -------- | ------- | ------- | ------- | ------- |
| taille d'une page | 4096 bytes || 0,417244 | 1,052614 | 2,206575 | 2,728802 | 2,667614 | 3,840667 | 3,225679 | 2,838925 | 3,08327  | 3,200055 | 3,089466 | 3,000447 | 3,019513 | 3,005894 | 33,554432 | 3,002937 | 2,991321 | 3,021358 | 2,892986 | 1,338193 | NO DATA | NO DATA |
|  | 8192 bytes || 0,168996 | 0,349509 | 0,683139 | 0,141819 | 1,446758 | 1,509284 | 1,542311 | 1,560038 | 1,559075 | 1,614879 | 1,524303 | 1,565755 | 1,523921 | 1,543095 | 1,540164  | 1,541204 | 1,552684 | 1,542094 | 1,530998 | 1,550697 | NO DATA | NO DATA |
| limite  physique | 16777216 bytes || 0,025335 | 0,049745 | 0,101512 | 0,201422 | 0,401311 | 0,718496 | 1,513518 | 3,167406 | 6,338037 | 11,818271 | 22,093042 | 41,138576 | 70,58423 | 112,760548 | 160,28159 | 175,648635 | 187,806167 | 144,902541 | 201,301514 | 222,111602 | 209,539294 | 201,435235 |
|  | 33554432 bytes || 0,013488 | 0,026951 | 0,054109 | 0,106431 | 0,211348 | 0,419089 | 0,849805 | 0,262144 | 3,393225 | 6,501007 | 12,889807 | 24,789687 | 43,963178 | 77,903422 | 119,398023 | 157,91212 | 186,447483 | 101,510421 | 193,968239 | 189,454456 | 187,166709 | 189,345246 |
|  | 67108864 bytes || 0,006955 | 0,01342 | 0,027893 | 0,056245 | 0,110118 | 0,213905 | 0,42955 | 0,878561 | 1,769212 | 3,484547 | 6,871596 | 13,326233 | 25,498334 | 47,297371 | 80,136575 | 125,411652 | 164,294626 | 68,356216 | 174,896589 | 178,552567 | 184,419721 | 183,548209 |

##### graphique

![resultat buffer](.\chart.png)

##### discutions

on constate que pour les petits fichier il est très difficile de déterminer exactement qu'elle taille de buffer est le plus adapté car le moindre changement de contexte, ou autre baisse de performance passagère sur notre système baisse trop nos performances sur un aussi court temps. Nous discuterons donc des résultats à partir de 524 kB. On peu constater que plus la taille du buffer augmente plus nous sommes rapides jusqu'à ce que nous dépassons la limite physique de notre ram qui semblerais légèrement ralentir. Nous sommes un peu perplexe quand à ce résultat car notre programme n'a pas accès à exactement toutes les 4093084 pages  physiques mais c'est ce que nos expériences semblent démontrer. Peu être qu'un autre facteur auquel nous ne pensons pas rentre en compte mais il semblerais que la taille de buffer a 16777216 Byte (2GB) soit la plus optimal.

fait intéressant il semblerais que vers les 134 MB (taille de fichier) nous avons une chute de performance dont nous n'avons pas eu le temps d'en investigué la cause. 

## FLAG send et rcv

en lisant les page man des fonction send et rcv nous avons changer nos codes en utilisant le flag MSG_MORE pour le send (qui permet de mieux gérer les problèmes de cork) et MSG_WAITALL pour le rcv qui permet de bloquer l'opération jusqu'à ce qu'elle soit entièrement satisfaite ou reception du signal de fin. 

```c
# pour le recive
retr = recv(sock, &buf, BUFFER_SIZE, MSG_WAITALL);
# pour le send 
send(sock, &buf, ret, MSG_MORE);
```

### mesure 

comme nous savons que nous allons prendre une "grande" taille de buffer nous choisisons de regarder les resultats uniquement pour une taille de buffer correspondant à la limite physique de notre ram, ainsi que le double et le quadruple pour voir ce qui se passe lorsque je dépasse cette capacité matériel. 

|          |      | 1 KB     | 2 kB     | 4.1 kB   | 8.2 kB   | 16 kB    | 33 kB    | 66 kB    | 131 kB   | 268 kB   | 524 kB    | 1 MB      | 2.1 MB    | 4.2 MB    | 8.4 MB     | 17 MB      | 34 MB      | 67  MB     | 134 MB     | 268 MB     | 537 MB     | 1.1 GB     | 2.1 GB     |
| -------- | ---- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- | --------- | --------- | --------- | --------- | ---------- | ---------- | ---------- | ---------- | ---------- | ---------- | ---------- | ---------- | ---------- |
| 16777216 |      | 0,025827 | 0,05091  | 0,102639 | 0,207009 | 0,406993 | 0,822419 | 1,623664 | 3,226747 | 6,518514 | 12,091281 | 22,962363 | 45,406686 | 77,650536 | 129,334637 | 189,402018 | 246,398981 | 299,835431 | 168,203294 | 351,935624 | 343,482224 | 353,952494 | 364,891057 |
| 33554432 |      | 0,013348 | 0,024275 | 0,050828 | 0,107856 | 0,208245 | 0,386824 | 0,8003   | 1,548979 | 3,441297 | 6,79103   | 12,981383 | 25,188919 | 46,27     | 83,850373  | 135,060663 | 198,401022 | 252,396627 | 118,142129 | 333,519417 | 348,337741 | 363,666181 | 265,428926 |
| 67108864 |      | 0,006712 | 0,013502 | 0,02692  | 0,053968 | 0,10682  | 0,209142 | 0,425506 | 0,852046 | 1,688708 | 3,358748  | 6,767895  | 12,652868 | 25,269971 | 45,571146  | 71,342227  | 122,710174 | 161,524602 | 66,001991  | 240,009175 | 258,047618 | 265,256435 | 277,295811 |

### graphique 

![resultat buffer](.\chart_flag.png)

#### discussions

nous remarquons toujours cette baise spectaculaire des performances au alentour des 134MB , le buffer avec la taille correspondant au nombre de page physique semble toujours être la plus performante. Il faut faire mention de cette chute pour le buffer qui possède le double pour le fichier de 2.1 GB, nous avons eu beau recommencer l'expérience le résultat était toujours similaire, nous n'avons pas eu le temps d'investigué plus en profondeur.

Nous avons grâce à ces flags gagner en performance de l'ordre de quelque 100 MBytes/sec.

### conclusion

nous n'avons pas eu le temps de tester d'autre mesure mais nous sommes déjà satisfait de l'amélioration que nous avons pu effectuer, le gain de performance le plus significatif était bien sur la bufferisassions. Les flags mentionner ci-dessus on permis qu'une petite amélioration par rapport au pas précédent. Nous avons imaginez d'autre piste (voir partie suivante) , mais pensons que nous n'arriveront pas a faire d'autre amélioration majeur. Nous vous laissons donc le loisirs de découvrir les quelques investigations supplémentaire que nous avons fait dans la partie suivante mais nous décidons de rendre notre solution après cette dernière étape de flag.

### autre piste exploitable

Nous avons essayer de ne plus incrémenter tout les byte un par 1, car comme notre tableaux (qui nous sert de buffer) est de taille fixe (correspondant un un byte par ligne) il aurait fallut additionner de 0x11111111 (avec autant de 1 que de ligne) afin d'augmenter tout les bits de 1 en une seul fois. Ce nombre est très facilement calculable (somme d'une suite géométrique de raison 0x10). Mais nous nous sommes très vite frotter au limite de calcul du c en se qui concerne les overflow, il aurait été très fastidieux (pour nous avec nos compétences dans ce langage) de faire cela sans compter que nous ne sommes pas sur que cela aurait augmenter les performances car en effet s'il est très rapide de faire une addition de 1 une autre addition est plus gourmande. Cette option reste donc une piste envisageable en cas de volonté d'amélioré encore notre code.

Nous avons aussi essayer de changer les options de compilation GCC, avec le flag -O3 par exemple mais cella n'a pas été concluant, dans un but d'amélioré encore notre code il faudrait peu être mieux investigué de ce coter là.

Nous avons aussi créer des threads que ce soit du coter serveur (un thread qui lit le fichier et un autre qui envois au client), ainsi que du coter client (un thread qui reçoit les donné et un autre qui les écrit) mais malheureusement cela sans aucun gain de performance. A notre avis il semblerai que cette solution peu être plus efficace si nous avons plus de client, et dans ce cas créer des pool worker comme nous avons vue dans d'autre cours. 

Nous avons aussi essayer d'allouer dynamiquement à l'aide de malloc notre buffer malheureusement nous n'avons pas réussi dans le temps impartit à dépasser notre incompétence en c . nous pensions qu'il suffisait d'écrire :

``` C
uint8_t* buf = NULL;
buf = malloc(BUFFER_SIZE*sizeof(uint8_t));
```

ainsi que des free(buf) a chaque sortie possible de notre programme mais nous nous sommes malheureusement toujours confronté à des problème de SEGFAULT due à nos erreurs de programmation. Nous ne savons donc pas si allouer dynamiquement les buffers sont plus efficace ou non.

