#pragma once

void srv_start(const unsigned short port_srv);
