# HPC labo 8

#### auteur : Alexandre Gabrielli

#### date : 04.06.2020

## objectif

le but de ce laboratoire est d'utilisé des fonction SIMD sur un code donné (générateur de fractale). le but étant d'augmenter le débit des points générés dans ce programme 

## métrique de base

Une première exécution de la fonction ./ifs-bm nous permet d'avoir des métriques de bases sur lequel nous pourront travailler. 

![start](.\start.png)

## adaptation du code 

le code qui généré les points est constituer principalement d'une boucle qui itère point par point, notre but est de faire en sorte que cette boucle généré 4 points à la fois grâce au instruction SMID .

pour ce fait nous n'utiliserons plus de simple float : 

```c
    float p_x = 0.0f;
    float p_y = 0.0f;
```

deviens

```c
    points_x = _mm_set_ps(0,0,0,0);
    points_y = _mm_set_ps(0,0,0,0);
```

au début du programme nous choisissons un nombre généré par une fonction (xorshift32)  que nous utilisions pour choisir quel matrice de transformation nous allons utilisé. Comme nous effectuons 4 points par 4 points nous devons utilisé 4 nombre généré de cette matière c'est pourquoi nous avons fait la fonction xorshift128 qui prend un __m128i* et permet de générer c'est 4 nombre grâce à des instructions SMID. 

Comme il n'y a qu'un nombre de matrice de transformation limiter il est nécessaire de faire un modulo pour chacun des quatre nombres généré. Comme il est complexe d'effectuer cette opération en SMID nous avons stocker ces quatre chiffres dans un tableau et nous effectuons les modulos un par un 

```c
        uint32_t tab[4] = {};
        _mm_store_si128((__m128i *)tab,rand_idxs);

        int i;
        for ( i = 0 ; i< 4 ; i++){
            tab[i]%=ifs->nb_transforms;
            tab[i]*=TRANSFORM_SIZE;
            }
```

Nous savons que cette partie du code est un point amélioration car il est possible de l'effectuer avec des instructions SMID. 

A la suite du code il faut appliquer la transformation, pour ce faire rien de plus simple car le choix du tableau de transformation se trouve dans tab tab[0] pour le premier points tab[1] pour le deuxième, etc il faut donc effectuer les opération de multiplication et d'addition en SMID en choisissant bien la bonne table de transformation a chaque fois. ces opération son effectuer dans le code de la ligne 164 à 228.

Pour la suite du programme nous avons choisi de repasser en opération sans SMID pour ce faire nous repassons les points dans des tableau et itérons sur ces tableau 

```c
        float pointsX [4] ={};
        float pointsY [4] = {};
        _mm_store_ps(pointsX , points_x);
        _mm_store_ps(pointsY , points_y);
```

il s'agit bien évidement d'un gros point d'amélioration que nous n'effectuons pas par manque de temps.

## ligne 144 itération = count_points/4

Comme nous avons 4* plus de points généré nous avons multiplier le count_points par 4, comme nous itérons sur ce count_point si nous voulons le même nombre d'itération de transformation par points que précédemment nous devons donc divisé par quatre le nombre itération par rapport au count_points. 

## résultat

![start](.\resultat.png)

Comme nous pouvons le voir nous avons réussi avec le même temps exécution de généré environ 4 fois plus de points ce qui était l'objectif de départ 

## points d'amélioration possible 

#### lisibilité du code

par soucis de simplicité nous avons remplacé la fonction affine_transform par du code, il aurait été judicieux de faire un appel de fonction quitte à la déclaré inline afin de laisser la lisibilité du code intacte. 

#### nombreux points pas en SMID

comme expliquer le long de ce rapport toute les opérations se rattachant au 4 points ne sont pas forcément en SMID, un point d'amélioration est donc de réussir a tout faire en SMID, bien sur il faudra voir pour chacune des modifications si cella est réellement plus rapide (typiquement le modulo) mais normalement nous pouvons encore gagner quelque performance à ce niveau là. 

## conclusion

nous avons dans ce laboratoire réussi a utilisé les instructions SMID pour amélioré notre code. Nous avons surtout utilisé les instruction simple comme les additions multiplication shift  mais nous aurions pu aussi les utilisés pour faire les comparaison et quelques instructions plus complexe que nous avons laissé de coter par soucis de temps. Cela reste un point d'amélioration donc nous sommes conscient. 

